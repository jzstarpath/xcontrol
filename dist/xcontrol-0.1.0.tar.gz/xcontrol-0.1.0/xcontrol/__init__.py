"""
Library for X Controller by Precision Robotics.
"""

__version__ = "0.1.0"
__author__ = "Saurav Shroff"
